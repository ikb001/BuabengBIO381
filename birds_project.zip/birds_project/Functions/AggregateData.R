# --------------------------------------
# FUNCTION aggregate_data
# required packages: foreach, stringr, and tidyverse 
# description: This function aggregates the data downloaded from the NEON website
# inputs: Data from the NEON website
# outputs: Species Abundance and Richness
########################################
# Load necessary libraries at the beginning of the script
library(foreach)
library(stringr)
library(tidyverse)

# Define the aggregate_data function
aggregate_data <- function(){
  # define the main folder to aggregate data from
  main_dir <- "~/compbioproj/BuabengBIO381/birds_project/OriginalData/NEON_count-landbird/"
  
  # aggregate the files from the folder in the main directory
  count_data <-list.files(path = main_dir, 
                          pattern = "\\.brd_countdata.*\\.csv$",
                          recursive = TRUE, 
                          full.names = TRUE)
  
  # loop through the files to process them
  aggregated_results <- foreach(file=count_data, .combine = rbind) %do% {
    
    # Read the CSV file
    data <- read.csv(file)
    
    # Clean data - only remove rows with NA in critical columns
    data <- data[!is.na(data$scientificName) & !is.na(data$pointCountMinute), ]
    
    # Calculate metrics
    abundance <- nrow(data)  # Number of observations
    richness <- length(unique(data$scientificName))
    
    # Extract year from filename 
    year <- as.numeric(gsub(".*(201[5-9]|202[0-3]).*", "\\1", basename(file)))
    
    # #aggregate the results of the operation into the initialized dataframe
    aggregated_results <- data.frame(
      file = basename(file),
      year = year,
      abundance = abundance,
      species_richness = richness
    )
    
    return(aggregated_results)
    
  }
  
} 
# end of function aggregate_data
# --------------------------------------
# aggregate_data()
