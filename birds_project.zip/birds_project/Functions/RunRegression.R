# --------------------------------------
# FUNCTION run_regression
# required packages: car, ggplot2
# description:
# inputs:
# outputs:
########################################

# load the required libraries
library(car)
library(ggplot2)

# construct the function for the regression
run_regression <- function(bird_data){

  # perform the regression
model <- lm(species_richness ~ abundance, data = bird_data)

# Check 1: Residual non-linearity
# Store residuals and fitted values
res_data <- data.frame(
  residuals = residuals(model),
  fitted = fitted(model),
  res_qq = residuals(model) 
)

# Create diagnostic plots
plots <- list(
  residual_fitted = ggplot(res_data, aes(x = fitted, y = residuals)) + 
    geom_point() +
    theme_classic(),
  qq_plot = ggplot(res_data, aes(sample = res_qq)) + 
    stat_qq() + 
    stat_qq_line() +
    theme_classic()
)

# Return all components as a list
return(list(
  model = model,
  plots = plots
))

}
# end of function run_regression
# --------------------------------------
# run_regression()
