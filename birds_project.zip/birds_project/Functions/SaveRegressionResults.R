# --------------------------------------
# FUNCTION save_regression_results
# required packages: ggplot2
# description: This function saves our regression outputs from the other function
# inputs: regression model
# outputs: qqplots, residual plots and model results
########################################
# load the required libraries
library(ggplot2)

save_regression_results <- function(regression, output_path) {
  # Extract key components
  coefficients_df <- as.data.frame(coef(summary(regression$model)))
  model_stats <- data.frame(
    R_squared = summary(regression$model)$r.squared,
    Adj_R_squared = summary(regression$model)$adj.r.squared
  )
  
  # Combine into one table
  final_table <- cbind(
    Coefficients = rownames(coefficients_df),
    coefficients_df,
    model_stats
  )
  
  # Save to CSV
  write.csv(final_table, file = output_path, row.names = FALSE)
  
  # Save plots separately (i.e. one for the residuals and one for the qqplots)
  ggsave(
    filename = file.path(dirname(output_path), "residual_plot.png"),
    plot = regression$plots$residual_fitted
  )
  ggsave(
    filename = file.path(dirname(output_path), "qq_plot.png"),
    plot = regression$plots$qq_plot
  )
}
# end of function save_regression_results
# --------------------------------------
# save_regression_results()
