# --------------------------------------
# FUNCTION visualize_data
# required packages: ggplot2
# description:
# inputs:
# outputs:
########################################
# load the necessary libraries
library(ggplot2)

#let's visualize our data
visualize_data <- function(bird_data, output_path){
# make a histogram for species abundance across the years
sps_abd <- ggplot(bird_data, aes(x = factor(year), y = abundance, fill = factor(year))) +
  labs(x = "Year", y = "Total Abundance") +
    geom_col() +
    theme_classic() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
sps_richness <- ggplot(bird_data, aes(x = factor(year), y = species_richness, fill = factor(year))) +
  geom_col() +
  labs(x = "Year", y = "Species Richness")+
  theme_classic() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Save plots separately
ggsave(
  filename = file.path(dirname(output_path), "sps_abd_plot.png"),
  plot = sps_abd,
  width = 8, height = 6, units = "in")

ggsave(
  filename = file.path(dirname(output_path), "sps_richness_plot.png"),
  plot = sps_richness,
  width = 8, height = 6, units = "in")
} 

# end of function visualize_data
# --------------------------------------
# visualize_data()
