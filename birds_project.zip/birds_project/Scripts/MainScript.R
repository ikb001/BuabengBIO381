# main script for executing all our commands & functions
# Isaac Buabeng
# 3/28/2025

# Step 1: Listing entire project components
## download 10 years of data on breeding land birds (2013 -2023)
## set up a log file for the project
## create separate user-defined functions for the operations below:
## extract data on abundance and species richness each yearly data sheet 
## run a simple regression model of Species richness vs. total abundance 
## create a histogram, across years, of the abundance and a separate histogram of species richness

# Step 2: batch process each folder to execute the functions
# Step 3: Upload all files unto the webpage.

###########################
# let's begin writing
##########################

#let's load the needed libraries
require(upscaler)
require(pryr)
require(skimr)
require(car) # needed for running our regressions
require(ggplot2)
require(ggtern)
require(foreach)
require(stringr)
require(tidyverse)

# let's create our log file
set_up_log()

# let's make the scripts for our functions
l("writng our functions")
build_function(c("aggregate_data","run_regression", "visualize_data"))

# Source all function templates as a batch operation
l("sourcing our functions")
source_batch("Functions")

# Run each function template
l("running each function's template")
aggregate_data()
run_regression()
visualize_data()

# Let's aggregate and clean our data
l("aggregating and cleaning our data")
bird_data <- aggregate_data()
bird_data

# write the cleaned data into a csv file
l("writing our data into a csv file")
write.table(bird_data, file="C:/Users/User/Documents/compbioproj/BuabengBIO381/birds_project/CleanedData/cleaned_bird_data.csv", sep = ",")

# run a linear regression model on the cleaned data for Species Richness (S) vs. Abundance for every year
l("running a linear regression model on our data")
regression <- run_regression(bird_data)
regression

# let's build another function to save our regression results
build_function("save_regression_results")
source_batch("Functions")
save_regression_results()

# now let's save the regression results, to do this i'd need the results itself and the output path
save_regression_results(regression = regression, output_path = "~/compbioproj/BuabengBIO381/birds_project/Outputs/regression_output.csv") #i've moved the plots into the plots folder.

# visualize the data
l("let's visualize our data")
visualize_data(bird_data, output_path = "~/compbioproj/BuabengBIO381/birds_project/Plots/")

#######end of script##########################################
